registrat = False
intents = 3
nom = ""
contrasenya = ""

while not registrat:
    
    print("1º Pas: Registra't per a la loteria")
    nom = input("Introdueix el teu nom: ")
    confirma_nom = input("Confirma el teu nom: ")
    
    if confirma_nom == nom:
        contrasenya = input("2º Pas: Crea una contrasenya:")
        contrasenya = contrasenya + "_" + nom + contrasenya
        print("Registre exitós. La teva nova contrasenya és:", contrasenya)
        registrat = True
        
    else:
        print("El nom de confirmació no coincideix amb el nom introduït. Torna-ho a intentar.")

while intents > 0:
    password = input("Introdueix la teva contrasenya per accedir: ")
    if password == contrasenya:
        print("Accés")
        break
    else:
        print("Contrasenya incorrecta. Et queden", intents - 1, "intents.")
        intents -= 1
        if intents == 0:
            print("Has excedit el nombre d'intents. Torna a intentar més tard.")
            break
